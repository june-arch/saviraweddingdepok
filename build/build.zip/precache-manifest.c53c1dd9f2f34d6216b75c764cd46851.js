self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "59d345a4e8f000683b611b33dd194740",
    "url": "/index.html"
  },
  {
    "revision": "8653138d36fa1ea40ada",
    "url": "/static/css/2.5bc09813.chunk.css"
  },
  {
    "revision": "01eeaf5c2923b397358f",
    "url": "/static/css/main.7cfff090.chunk.css"
  },
  {
    "revision": "8653138d36fa1ea40ada",
    "url": "/static/js/2.0bc71b5d.chunk.js"
  },
  {
    "revision": "8de4bdbb127f280cc6b79279dd69f244",
    "url": "/static/js/2.0bc71b5d.chunk.js.LICENSE"
  },
  {
    "revision": "01eeaf5c2923b397358f",
    "url": "/static/js/main.b0d43d70.chunk.js"
  },
  {
    "revision": "13816ae3f249c49b17ef",
    "url": "/static/js/runtime-main.a832b73a.js"
  },
  {
    "revision": "e6f1299cfe9aaeafa04ca078c1343450",
    "url": "/static/media/1-min.e6f1299c.jpeg"
  },
  {
    "revision": "dae2fd23aac9c4be423228a355b7fc19",
    "url": "/static/media/2-min.dae2fd23.jpg"
  },
  {
    "revision": "f72c261a9c48992dfbad20c5a7f1d134",
    "url": "/static/media/3-min.f72c261a.jpeg"
  },
  {
    "revision": "11cedb5ef5fd36d48f817c81a62f6b1b",
    "url": "/static/media/4-min.11cedb5e.jpg"
  },
  {
    "revision": "41791e27ee0ae090a5c295928e6b107f",
    "url": "/static/media/5-min.41791e27.jpg"
  },
  {
    "revision": "37da17e91c4d4ed0bcfc462dada4fd82",
    "url": "/static/media/6-min.37da17e9.jpeg"
  },
  {
    "revision": "270cd2443b7731c75ab8c92ea55d0a2c",
    "url": "/static/media/background-body.270cd244.jpeg"
  },
  {
    "revision": "52e753591e47bfff477694360122aaaf",
    "url": "/static/media/close.52e75359.svg"
  },
  {
    "revision": "7bab216994f83293161e4f910f848c6a",
    "url": "/static/media/comment-grey.7bab2169.svg"
  },
  {
    "revision": "2b460e5bf54504b33b5e421c15831a68",
    "url": "/static/media/comment-white-oval-bubble.2b460e5b.svg"
  },
  {
    "revision": "1d965015435d8d062b31164b9f654eac",
    "url": "/static/media/facebook-logo.1d965015.svg"
  },
  {
    "revision": "6171a487c77f160f5748712508bf95b9",
    "url": "/static/media/gal1.6171a487.webp"
  },
  {
    "revision": "9c6c60dbbe60da4c224779080e59bb62",
    "url": "/static/media/instagram-grey.9c6c60db.svg"
  },
  {
    "revision": "f75e2600e08199c82c07e91e8200bb8b",
    "url": "/static/media/instagram-logo.f75e2600.svg"
  },
  {
    "revision": "f5c5940d9d255395ed4f316dc3f4a6a7",
    "url": "/static/media/like-grey.f5c5940d.svg"
  },
  {
    "revision": "06122dc29220cb896f2ee47b5f285103",
    "url": "/static/media/like.06122dc2.svg"
  },
  {
    "revision": "0c0b4219b1e87c70e7cc822b1422a5a5",
    "url": "/static/media/logo.0c0b4219.png"
  },
  {
    "revision": "03928acd573c99782972aaaa132d238c",
    "url": "/static/media/makeup_artist.03928acd.webp"
  },
  {
    "revision": "a0bdf1cd0647d7bde4605faf86b54e85",
    "url": "/static/media/paper.a0bdf1cd.svg"
  },
  {
    "revision": "693d809f0d9f66c406305bd3c11cf32e",
    "url": "/static/media/video.693d809f.svg"
  }
]);